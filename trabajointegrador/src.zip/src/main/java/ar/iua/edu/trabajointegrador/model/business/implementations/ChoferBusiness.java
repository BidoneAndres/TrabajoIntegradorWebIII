package ar.iua.edu.trabajointegrador.model.business.implementations;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ar.iua.edu.trabajointegrador.model.Chofer;
import ar.iua.edu.trabajointegrador.model.business.exceptions.BusinessException;
import ar.iua.edu.trabajointegrador.model.business.exceptions.FoundException;
import ar.iua.edu.trabajointegrador.model.business.exceptions.NotFoundException;
import ar.iua.edu.trabajointegrador.model.business.interfaces.IChoferBusiness;
import ar.iua.edu.trabajointegrador.model.persistence.ChoferRepository;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ChoferBusiness implements IChoferBusiness {
	@Autowired
	private ChoferRepository choferDAO;
	
	@Override
	public List<Chofer> list() throws BusinessException {
		try {
			return choferDAO.findAll();
		}catch(Exception e){
			log.error(e.getMessage(), e);
			throw BusinessException.builder().ex(e).build();
		}
	}

	@Override
	public Chofer load(long id) throws NotFoundException, BusinessException {
		Optional<Chofer> choferFound;
		try {
			choferFound = choferDAO.findById(id);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			throw BusinessException.builder().ex(e).build();
		}
		if (choferFound.isEmpty())
			throw NotFoundException.builder().message("El chofer "+ id + "no se encuentra").build();
		return choferFound.get();
	}
	
	public Chofer load(String documento) throws NotFoundException, BusinessException {
		Optional<Chofer> choferFound;
		try {
			choferFound = choferDAO.findByDocumento(documento);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			throw BusinessException.builder().ex(e).build();
		}
		if (choferFound.isEmpty())
			throw NotFoundException.builder().message("El chofer "+ documento + "no se encuentra").build();
		return choferFound.get();
	}

	@Override
	public Chofer addChofer(Chofer chofer) throws FoundException, BusinessException {

	    //Verificar si el Chofer ya existe (Recomendación: Mover la búsqueda al inicio)
	    Optional<Chofer> foundChofer = choferDAO.findByDocumento(chofer.getDocumento());

	    //Controlar la FoundException si ya existe un Chofer con ese documento
	    if (foundChofer.isPresent()) {
	        // Si ya existe, lanzamos la excepción específica FoundException
	        throw new FoundException("Ya existe un Chofer registrado con el documento: " + chofer.getDocumento());
	    }

	    try {
	        //Persistir (guardar) el nuevo Chofer
	        return choferDAO.save(chofer);
	    } catch (Exception e) {
	        //Manejo de errores de persistencia
	        log.error("Error al intentar guardar el Chofer con documento {}: {}", chofer.getDocumento(), e.getMessage(), e);

	        throw BusinessException.builder().ex(e).build();
	    }
	}
}

