package ar.iua.edu.trabajointegrador.model;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@Entity
@Table(name = "datos_carga")
@EntityListeners(AuditingEntityListener.class) // para las timestamps
public class DatoCarga {
	@Schema(hidden = true)
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	//asociamos al numero de orden
	
	@ManyToOne(fetch = FetchType.LAZY)  // ->importante, sino me va a traer en cada coNSULTA todas las veces la otden entera
	@JoinColumn(name="orden_id",nullable = false)//da mas detalles, clave foranea, 
	private Orden orden;
	
	private double masaAcumulada;
	private double densidadProducto;
	private int temperatura;
	private double caudal;
	
	// --- TIMESTAMPS AUTOMÁTICOS ---

    @CreationTimestamp //  Anotación para la fecha de creación
    @Column(nullable = false, updatable = false) // No se puede actualizar
    private LocalDateTime timestamp;
}
