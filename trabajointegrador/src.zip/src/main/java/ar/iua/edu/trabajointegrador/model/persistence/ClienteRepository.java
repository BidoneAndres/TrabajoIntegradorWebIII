package ar.iua.edu.trabajointegrador.model.persistence;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import ar.iua.edu.trabajointegrador.model.Cliente;

public interface ClienteRepository extends JpaRepository<Cliente, Long>{
	public Optional<Cliente> findByRazonSocial(String razonSocial);
	public Optional<Cliente> findByRazonSocialAndIdNot(String razonSocial, long id);
}
